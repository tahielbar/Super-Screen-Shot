// Screen Shut — lógica de captura (Manifest V3)

const btnVisible = document.getElementById('btn-visible');
const btnFull = document.getElementById('btn-full');
const statusBox = document.getElementById('status-box');
const statusText = document.getElementById('status-text');
const bar = document.getElementById('bar');
const barFill = document.getElementById('bar-fill');

// Chrome permite ~2 capturas por segundo; esperamos entre cada una.
const WAIT_AFTER_SCROLL_MS = 650;
// Límite seguro de alto del canvas (en píxeles reales).
const MAX_CANVAS_PX = 30000;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/* ---------- Interfaz ---------- */

function setStatus(text, kind = '', percent = null) {
  statusText.textContent = text;
  statusBox.className = kind; // '', 'ok' o 'error'
  if (percent === null) {
    bar.hidden = true;
  } else {
    bar.hidden = false;
    barFill.style.width = Math.max(0, Math.min(100, percent)) + '%';
  }
}

function setBusy(busy) {
  btnVisible.disabled = busy;
  btnFull.disabled = busy;
}

/* ---------- Utilidades ---------- */

function timestamp() {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}_` +
         `${p(d.getHours())}-${p(d.getMinutes())}-${p(d.getSeconds())}`;
}

function downloadUrl(url, filename) {
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
}

function loadImage(src) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('No se pudo leer la captura.'));
    img.src = src;
  });
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.url || !/^(https?|file):/.test(tab.url)) {
    throw new Error('Esta página no se puede capturar (páginas de Chrome, Web Store, etc.).');
  }
  return tab;
}

async function runInPage(tabId, func, args = []) {
  const [res] = await chrome.scripting.executeScript({ target: { tabId }, func, args });
  return res.result;
}

// captureVisibleTab con reintentos por si se supera el límite por segundo
async function captureVisible() {
  for (let intento = 0; intento < 4; intento++) {
    try {
      return await chrome.tabs.captureVisibleTab(null, { format: 'png' });
    } catch (e) {
      if (intento === 3) throw e;
      await sleep(1000);
    }
  }
}

/* ---------- Funciones que se ejecutan DENTRO de la página ---------- */

function pageGetMetrics() {
  const de = document.documentElement;
  const b = document.body;
  window.__ssOrig = { x: window.scrollX, y: window.scrollY, behavior: de.style.scrollBehavior };
  de.style.scrollBehavior = 'auto';
  const totalHeight = Math.max(
    de.scrollHeight, de.offsetHeight,
    b ? b.scrollHeight : 0, b ? b.offsetHeight : 0
  );
  return {
    totalHeight,
    viewH: window.innerHeight,
    viewW: window.innerWidth
  };
}

function pageScrollTo(y) {
  window.scrollTo(0, y);
  return window.scrollY;
}

function pageHideFixed() {
  window.__ssHidden = [];
  document.querySelectorAll('*').forEach((el) => {
    const pos = getComputedStyle(el).position;
    if (pos === 'fixed' || pos === 'sticky') {
      window.__ssHidden.push([
        el,
        el.style.getPropertyValue('visibility'),
        el.style.getPropertyPriority('visibility')
      ]);
      el.style.setProperty('visibility', 'hidden', 'important');
    }
  });
}

function pageRestore() {
  (window.__ssHidden || []).forEach(([el, value, prio]) => {
    if (value) el.style.setProperty('visibility', value, prio);
    else el.style.removeProperty('visibility');
  });
  window.__ssHidden = [];
  const o = window.__ssOrig;
  if (o) {
    window.scrollTo(o.x, o.y);
    document.documentElement.style.scrollBehavior = o.behavior;
  }
}

/* ---------- Captura normal ---------- */

async function takeVisible() {
  setBusy(true);
  try {
    setStatus('CAPTURANDO...', '', null);
    await getActiveTab();
    const dataUrl = await captureVisible();
    downloadUrl(dataUrl, `Screen-Shut_${timestamp()}_normal.png`);
    setStatus('LISTO. Guardada en Descargas.', 'ok');
  } catch (e) {
    setStatus('ERROR: ' + e.message, 'error');
  } finally {
    setBusy(false);
  }
}

/* ---------- Captura de página completa ---------- */

async function takeFull() {
  setBusy(true);
  let tab = null;
  try {
    tab = await getActiveTab();
    setStatus('PREPARANDO... No cierres esta ventana.', '', 0);

    const m = await runInPage(tab.id, pageGetMetrics);

    // Primer cuadro (arriba de todo)
    await runInPage(tab.id, pageScrollTo, [0]);
    await sleep(WAIT_AFTER_SCROLL_MS);
    const firstUrl = await captureVisible();
    const firstImg = await loadImage(firstUrl);

    const scale = firstImg.width / m.viewW; // píxeles reales por píxel CSS
    let effHeight = m.totalHeight;
    let truncated = false;
    if (effHeight * scale > MAX_CANVAS_PX) {
      effHeight = Math.floor(MAX_CANVAS_PX / scale);
      truncated = true;
    }

    const canvas = document.createElement('canvas');
    canvas.width = firstImg.width;
    canvas.height = Math.round(effHeight * scale);
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(firstImg, 0, 0);

    const frames = Math.max(1, Math.ceil(effHeight / m.viewH));
    setStatus(`CAPTURANDO 1 DE ${frames}`, '', (1 / frames) * 100);

    if (frames > 1) {
      // Ocultamos menús fijos para que no se repitan en cada cuadro
      await runInPage(tab.id, pageHideFixed);
    }

    for (let i = 1; i < frames; i++) {
      const targetY = Math.min(i * m.viewH, Math.max(0, effHeight - m.viewH));
      const realY = await runInPage(tab.id, pageScrollTo, [targetY]);
      await sleep(WAIT_AFTER_SCROLL_MS);
      const url = await captureVisible();
      const img = await loadImage(url);
      ctx.drawImage(img, 0, Math.round(realY * scale));
      setStatus(`CAPTURANDO ${i + 1} DE ${frames}`, '', ((i + 1) / frames) * 100);
    }

    setStatus('GUARDANDO ARCHIVO...', '', 100);
    const blob = await new Promise((resolve, reject) =>
      canvas.toBlob((b) => (b ? resolve(b) : reject(new Error('La imagen es demasiado grande.'))), 'image/png')
    );
    const url = URL.createObjectURL(blob);
    downloadUrl(url, `Screen-Shut_${timestamp()}_completa.png`);
    setTimeout(() => URL.revokeObjectURL(url), 60000);

    setStatus(
      truncated
        ? 'LISTO. La página era muy larga: se guardó la parte de arriba.'
        : 'LISTO. Guardada en Descargas.',
      'ok'
    );
  } catch (e) {
    setStatus('ERROR: ' + e.message, 'error');
  } finally {
    if (tab) {
      try { await runInPage(tab.id, pageRestore); } catch (_) {}
    }
    setBusy(false);
  }
}

btnVisible.addEventListener('click', takeVisible);
btnFull.addEventListener('click', takeFull);
